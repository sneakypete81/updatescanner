#Update Scanner
Monitors webpages for updates